package INNERCLASS;

public interface cekLogin {
    public void prosesLogin();
}
